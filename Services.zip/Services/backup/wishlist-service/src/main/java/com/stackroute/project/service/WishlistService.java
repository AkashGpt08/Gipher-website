package com.stackroute.project.service;

import com.stackroute.project.Repository.FavoriteRepository;
import com.stackroute.project.common.messages.BaseResponse;
import com.stackroute.project.common.messages.CustomMessage;
import com.stackroute.project.dto.Topic;
import com.stackroute.project.dto.WishListDTO;
import com.stackroute.project.wishlist.models.Favorites;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class WishlistService {

    @Autowired
    FavoriteRepository favoriteRepository;

    public BaseResponse createWishList(WishListDTO wishListDTO){

        Favorites checkDuplicate=favoriteRepository.findWishListByUrlAndId(wishListDTO.getUrl().toLowerCase(),wishListDTO.getUserId());
        if(checkDuplicate!=null && checkDuplicate.getUrl().length()>0){
            return new BaseResponse( CustomMessage.RECOURD_FOUND_WISHLISH, HttpStatus.CREATED.value());
        }else {
            Favorites wishListEntity = copyWishListDtoToEntity(wishListDTO);

            favoriteRepository.save(wishListEntity);
            return new BaseResponse(Topic.WishList.getName() + CustomMessage.SAVE_SUCCESS_MESSAGE, HttpStatus.CREATED.value());
        }
    }

    public BaseResponse deleteWishList(int id){
        favoriteRepository.deleteByWisListId(id);
        return new BaseResponse(Topic.WishList.getName() + CustomMessage.DELETE_SUCCESS_MESSAGE, HttpStatus.CREATED.value());
    }

    public List<WishListDTO> getWishList(int  userId){
        Pageable pageable = PageRequest.of(0, 25, Sort.by(Sort.Order.desc("id")));
        List<Favorites> wishListEntityList=favoriteRepository.getWishList(userId,pageable).getContent();
        List<WishListDTO> copy = new ArrayList<>();
        WishListDTO wishList=null;
        for(Favorites wishListEntity:wishListEntityList){
            wishList=new WishListDTO();
            wishList.setId(wishListEntity.getId());
            wishList.setUserId(wishListEntity.getUserId());
            wishList.setUrl(wishListEntity.getUrl());
            copy.add(wishList);
        }
        return copy;
    }



    private Favorites copyWishListDtoToEntity(WishListDTO wishListDTO) {
        Favorites favorites = new Favorites();
        BeanUtils.copyProperties(wishListDTO, favorites);
        return favorites;
    }


}
