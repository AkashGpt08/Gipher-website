package com.stackroute.project.Repository;


import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.stackroute.project.wishlist.models.Favorites;
@Repository
public interface FavoriteRepository extends JpaRepository<Favorites, Integer> {

    @Query("from  Favorites where userId = :userId")
    Slice<Favorites> getWishList(Integer userId, Pageable pageable);

    @Query("from  Favorites where lower(url) = :url and userId=:userId")
    Favorites findWishListByUrlAndId(String url,Integer userId);

    @Modifying
    @Query("delete from  Favorites where  id = :id")
    void deleteByWisListId(Integer id);
}
