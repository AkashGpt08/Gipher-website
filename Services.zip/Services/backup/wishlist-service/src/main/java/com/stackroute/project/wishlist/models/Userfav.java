package com.stackroute.project.wishlist.models;

import java.util.List;

import org.springframework.data.annotation.Id;


/*
public class Userfav {
    @Id
    private String email;
    private List<Favorites> favorites;
}*/
