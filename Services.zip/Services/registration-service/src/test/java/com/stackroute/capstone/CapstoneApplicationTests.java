package com.stackroute.capstone;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CapstoneApplicationTests {

	@Test
	public void contextLoads() {
	}

}
