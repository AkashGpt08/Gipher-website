package com.app.gif.apicall.Domains;

public class Original {
    public String height;
    public String width;
    public String size;
    public String url;
    public String mp4_size;
    public String mp4;
    public String webp_size;
    public String webp;
    public String frames;
    public String hash;
}
