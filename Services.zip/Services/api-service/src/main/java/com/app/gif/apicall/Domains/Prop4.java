package com.app.gif.apicall.Domains;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class Prop4 {
    public String height;
    public String width;
    public String mp4_size;
    public String mp4;
}
