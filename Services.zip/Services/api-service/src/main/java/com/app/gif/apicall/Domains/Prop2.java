package com.app.gif.apicall.Domains;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Prop2 {
    public String height;
    public String width;
    public String size;
    public String url;
    public String webp_size;
    public String webp;
}
