package com.app.gif.apicall.Domains;

public class Prop {
    public String height;
    public String width;
    public String size;
    public String url;
}
